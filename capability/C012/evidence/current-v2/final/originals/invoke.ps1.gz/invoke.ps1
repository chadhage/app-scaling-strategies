param([Parameter(Mandatory=$true)][string]$Name,[Parameter(Mandatory=$true)][string[]]$NodeArgs,[int]$MaximumSeconds=1200,[ValidateSet('none','normal','heavy')][string]$Lease='none')
$ErrorActionPreference='Stop'
$deadline=[DateTimeOffset]::Parse('2026-11-11T23:06:54.4385459Z')
$remaining=($deadline-[DateTimeOffset]::UtcNow).TotalSeconds
if($remaining -le 60){throw 'C012 original deadline reserve: no new work'}
$run=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$repo=[IO.Path]::GetFullPath((Join-Path $run '..\..\..'))
$private=Join-Path $repo '.git\c12-64927fc0'
$candidate=Join-Path $private 'c2'
$runtime=Join-Path $candidate '.git\kanban-orchestrator\browser-runtime'
$env:C012_RUN=$run; $env:C012_METADATA=$PSScriptRoot; $env:C012_PRIVATE_ROOT=$private
$env:C012_GIT_REPOSITORY=$repo; $env:C012_RUNTIME=$runtime
$env:TEMP=$runtime; $env:TMP=$runtime; $env:TMPDIR=$runtime
$env:NODE_PATH=Join-Path $repo 'testing\browser\node_modules'
$env:C012_DEADLINE=$deadline.ToString('o')
Remove-Item Env:NODE_TEST_CONTEXT,Env:NODE_V8_COVERAGE,Env:CAPTURE_BROWSER_EVIDENCE -ErrorAction SilentlyContinue
if(Test-Path -LiteralPath $candidate){[IO.Directory]::CreateDirectory($runtime)|Out-Null}
function Identity($p,$role){$b=$p.StartTime.ToUniversalTime();@{pid=$p.Id;createdAtUtc7=$b.ToString('yyyy-MM-ddTHH:mm:ss.fffffffZ');createdAtFileTimeUtc=$b.ToFileTimeUtc().ToString();role=$role;phase=$Name;observedAtUtc7=[DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ss.fffffffZ')}}
$journal=Join-Path $PSScriptRoot 'processes.jsonl'
(Identity (Get-Process -Id $PID) 'current-v2-own-controller')|ConvertTo-Json -Compress|Add-Content -LiteralPath $journal
$slot=$null; $owner="worker-C012-current-v2-$Name"; $locks=$null
$helper=Join-Path $env:C012_LEGACY 'scripts\heavy-slot.ps1'
try {
  if($Lease -ne 'none'){
    $locks=Join-Path $run $(if($Lease -eq 'normal'){'mutation-locks'}else{'heavy-locks'})
    $slots=if($Lease -eq 'normal'){4}else{3}
    foreach($f in Get-ChildItem -LiteralPath $locks -File -ErrorAction SilentlyContinue){if($f.LastWriteTimeUtc -lt [DateTime]::UtcNow.AddMinutes(-55)){throw 'Foreign near-stale lease must not be deleted'}}
    foreach($q in Get-ChildItem -LiteralPath (Join-Path $locks 'queue') -File -ErrorAction SilentlyContinue){$foreign=0;if(-not[int]::TryParse(($q.BaseName -split '-')[-1],[ref]$foreign)-or-not(Get-Process -Id $foreign -ErrorAction SilentlyContinue)){throw 'Foreign stale ticket must not be deleted'}}
    $slot=& $helper -Action Acquire -Owner $owner -Slots $slots -LockDir $locks -MaxWaitMinutes 1
    @{phase=$Name;owner=$owner;lease=$Lease;slot=$slot;acquiredAtUtc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Compress|Add-Content -LiteralPath (Join-Path $PSScriptRoot 'leases.jsonl')
  }
  $stamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffff')
  $stdout=Join-Path $PSScriptRoot "$Name-$stamp.stdout.raw";$stderr=Join-Path $PSScriptRoot "$Name-$stamp.stderr.raw"
  $cwd=if(Test-Path -LiteralPath $candidate){$candidate}else{$repo}
  $quoted=@($NodeArgs|ForEach-Object {'"'+($_ -replace '"','\"')+'"'})
  $child=Start-Process -FilePath (Get-Command node).Source -ArgumentList $quoted -WorkingDirectory $cwd -NoNewWindow -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  $birth=Identity $child 'current-v2-own-capture-root'
  $birth|ConvertTo-Json -Compress|Add-Content -LiteralPath $journal
  $started=[DateTimeOffset]::UtcNow;$limit=[Math]::Min($MaximumSeconds,[Math]::Floor(($deadline-$started).TotalSeconds-60))
  try{
    while(-not$child.WaitForExit(1000)){
      $now=[DateTimeOffset]::UtcNow
      "$($now.ToString('o')) C012-current-v2 $Name"|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'heartbeat.txt')
      if($now -ge $deadline.AddSeconds(-60)-or($now-$started).TotalSeconds -ge $limit){
        $p=Get-Process -Id $child.Id -ErrorAction SilentlyContinue
        if($p-and$p.StartTime.ToUniversalTime().ToFileTimeUtc().ToString()-eq$birth.createdAtFileTimeUtc){Stop-Process -Id $child.Id -Force}
        throw 'C012 bounded root stop: no invented descendant cleanup authority'
      }
    }
    $child.WaitForExit();$code=$child.ExitCode
    @{phase=$Name;birth=$birth;exit=$code;completedAtUtc=[DateTimeOffset]::UtcNow.ToString('o');stdout=$stdout;stderr=$stderr;deadlineUtc=$deadline.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot "$Name-$stamp.completion.json")
    Get-Content -LiteralPath $stdout -Tail 30;Get-Content -LiteralPath $stderr -Tail 20
    if($code-ne0){throw "C012 current-v2 command failed: $Name exit $code; all raw retained"}
  }finally{$child.Dispose()}
}finally{
  if($null-ne$slot){& $helper -Action Release -Owner $owner -Slots $slots -LockDir $locks}
  "$([DateTimeOffset]::UtcNow.ToString('o')) C012-current-v2 $Name settled"|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'heartbeat.txt')
}
